"""SpaceX Health Tracker - monitoring software (demo).

  python main.py demo [normal|bad_sleep|critical]   fill the database and print a report
  python main.py status [--astronaut A1]            print the current report
  python main.py add --sleep 6.5 --exercise 90 --heart 72 --stress 5 --meals 3 --vitamins --diary "tired"
  python main.py serve [--port 8000]                start the JSON API
"""
import argparse
from datetime import date

from spacex_monitor.analyzer import analyse, ACTIONS
from spacex_monitor.gamification import progress, challenges, achievements
from spacex_monitor.models import DailyRecord, Status
from spacex_monitor.simulator import scenario, SCENARIOS
from spacex_monitor.storage import Storage

ICON = {Status.GREEN: "[GREEN ]", Status.YELLOW: "[YELLOW]", Status.RED: "[ RED  ]"}


def report(store, aid):
    hist = store.history(aid, days=7)
    if not hist:
        print("No data. Run: python main.py demo")
        return
    a = analyse(hist)
    t = hist[-1]
    print(f"\n=== SpaceX Health Tracker | astronaut {aid} | {t.date} ===")
    print(f"STATUS: {ICON[a.overall]} {a.overall.name} - {ACTIONS[a.overall]}\n")
    for name, st in a.indicators.items():
        print(f"  {name:<9}{ICON[st]}")
    print("\nAlerts:" if a.alerts else "\nNo alerts.")
    for al in a.alerts:
        print(f"  {ICON[al.level]} {al.message}")
    print("\nSleep (last 7 days): " + " ".join(f"{r.sleep_hours:.1f}" for r in hist))
    p = progress(store.history(aid))
    print(f"\nLevel {p['level']} | XP {p['xp']} | {p['to_next']} XP to next level")
    print("Challenges:   " + ", ".join(f"{k}: {'done' if v else 'open'}" for k, v in challenges(t).items()))
    print("Achievements: " + ", ".join(k for k, v in achievements(hist).items() if v) or "-")
    print("\nNote: limits in this demo are examples. Real limits must be set by medical experts.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default="spacex.db")
    sub = ap.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("demo"); d.add_argument("scenario", nargs="?", default="bad_sleep", choices=SCENARIOS)
    s = sub.add_parser("status"); s.add_argument("--astronaut", default="A1")
    a = sub.add_parser("add")
    a.add_argument("--astronaut", default="A1"); a.add_argument("--date", default=date.today().isoformat())
    a.add_argument("--sleep", type=float, required=True); a.add_argument("--exercise", type=int, required=True)
    a.add_argument("--heart", type=int, required=True); a.add_argument("--stress", type=int, required=True)
    a.add_argument("--meals", type=int, required=True); a.add_argument("--vitamins", action="store_true")
    a.add_argument("--diary", default="")
    v = sub.add_parser("serve"); v.add_argument("--port", type=int, default=8000)

    args = ap.parse_args()
    store = Storage(args.db)

    if args.cmd == "demo":
        for rec in scenario(args.scenario):
            store.save(rec)
        report(store, "A1")
    elif args.cmd == "status":
        report(store, args.astronaut)
    elif args.cmd == "add":
        store.save(DailyRecord(args.astronaut, args.date, args.sleep, args.exercise, args.heart,
                               args.stress, args.meals, args.vitamins, args.diary))
        report(store, args.astronaut)
    elif args.cmd == "serve":
        from spacex_monitor.api import serve
        serve(store, args.port)


if __name__ == "__main__":
    main()
