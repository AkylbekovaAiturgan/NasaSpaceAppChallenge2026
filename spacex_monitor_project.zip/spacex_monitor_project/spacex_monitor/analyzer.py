"""Rules engine: indicator status + early trend detection."""
from . import config as C
from .models import Alert, Assessment, DailyRecord, Status

G, Y, R = Status.GREEN, Status.YELLOW, Status.RED


def rate_sleep(v):
    t = C.THRESHOLDS["sleep_hours"]
    return G if v >= t["green_min"] else Y if v >= t["yellow_min"] else R


def rate_exercise(v):
    t = C.THRESHOLDS["exercise_min"]
    return G if v >= t["green_min"] else Y if v >= t["yellow_min"] else R


def rate_heart(v):
    t = C.THRESHOLDS["heart_rate"]
    if t["green"][0] <= v <= t["green"][1]:
        return G
    if t["yellow"][0] <= v <= t["yellow"][1]:
        return Y
    return R


def rate_stress(v):
    t = C.THRESHOLDS["stress"]
    return G if v <= t["green_max"] else Y if v <= t["yellow_max"] else R


def rate_food(rec):
    ok_meals = rec.meals >= C.THRESHOLDS["meals"]["green_min"]
    if ok_meals and rec.vitamins:
        return G
    return Y if (ok_meals or rec.vitamins) else R


def rate_indicators(rec: DailyRecord) -> dict:
    return {
        "sleep": rate_sleep(rec.sleep_hours),
        "exercise": rate_exercise(rec.exercise_min),
        "heart": rate_heart(rec.heart_rate),
        "stress": rate_stress(rec.stress),
        "food": rate_food(rec),
    }


def scan_diary(text: str):
    """Return the worst status found in the diary text (None if nothing found)."""
    t = text.lower()
    if any(w in t for w in C.DIARY_RED):
        return R
    if any(w in t for w in C.DIARY_YELLOW):
        return Y
    return None


def _avg(records):
    return sum(r.sleep_hours for r in records) / len(records)


def analyse(history: list) -> Assessment:
    """history = records sorted by date; the last one is 'today'."""
    if not history:
        raise ValueError("history is empty")
    today = history[-1]
    ind = rate_indicators(today)
    alerts = []

    for name, st in ind.items():
        if st != G:
            word = "in the red zone" if st == R else "outside the normal range"
            alerts.append(Alert(st, name.upper(), f"{name.upper()} is {word}"))

    d = scan_diary(today.diary)
    if d == R:
        alerts.append(Alert(R, "DIARY", "Serious symptom in the diary - contact doctors on Earth"))
    elif d == Y:
        alerts.append(Alert(Y, "DIARY", "Diary shows tiredness or stress"))

    # Trend 1: sleep under the goal several days in a row
    streak = 0
    for rec in reversed(history):
        if rec.sleep_hours < C.SLEEP_GOAL:
            streak += 1
        else:
            break
    if streak >= C.SLEEP_BAD_STREAK:
        alerts.append(Alert(Y, "SLEEP_STREAK", f"Bad sleep for {streak} days in a row"))

    # Trend 2: sleep falling, even if today's number is still normal
    if len(history) >= 6:
        last3, prev3 = history[-3:], history[-6:-3]
        if _avg(last3) < _avg(prev3) - C.SLEEP_DROP:
            alerts.append(Alert(Y, "SLEEP_TREND", "Early warning: sleep trend is going down"))

    # Several indicators getting worse together
    if sum(1 for s in ind.values() if s != G) >= C.MANY_BAD_INDICATORS:
        alerts.append(Alert(Y, "MULTI", "Several indicators are getting worse together"))

    overall = max([G] + [a.level for a in alerts])
    alerts.sort(key=lambda a: -a.level)
    return Assessment(overall, ind, alerts)


ACTIONS = {
    G: "Continue the usual plan.",
    Y: "Check the indicators and adjust the daily plan.",
    R: "Act at once and contact doctors on Earth.",
}
