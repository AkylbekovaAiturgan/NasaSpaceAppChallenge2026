"""Fake data for demos and tests (like sensors on a station)."""
from datetime import date, timedelta
from .models import DailyRecord

# (sleep, exercise, heart, stress, meals, vitamins) for 7 days
_SC = {
    "normal": [(7.5,130,62,3,3,1),(7.2,125,64,3,3,1),(7.8,140,60,2,3,1),(7.4,130,63,3,4,1),
               (7.6,128,62,3,3,1),(7.3,135,61,3,3,1),(7.5,130,62,3,3,1)],
    "bad_sleep": [(7.4,125,64,4,3,1),(7.0,120,66,4,3,1),(6.6,110,68,5,3,1),(6.2,100,70,5,3,0),
                  (5.8,90,72,6,2,0),(5.5,80,74,6,2,0),(5.2,70,76,7,2,0)],
    "critical": [(7.0,120,70,4,3,1),(6.5,110,75,5,3,1),(6.0,100,80,6,3,0),(5.5,80,85,7,2,0),
                 (5.0,60,92,8,2,0),(4.5,40,100,8,1,0),(4.0,30,118,9,1,0)],
}
_DIARY = {"normal": "Feeling good, calm day.",
          "bad_sleep": "Very tired, can't sleep well.",
          "critical": "Blurry vision and chest pain."}


def scenario(name: str, astronaut_id="A1", end=None) -> list:
    end = end or date.today()
    rows = _SC[name]
    out = []
    for i, (sl, ex, hr, st, ml, vt) in enumerate(rows):
        d = end - timedelta(days=len(rows) - 1 - i)
        out.append(DailyRecord(astronaut_id, d.isoformat(), sl, ex, hr, st, ml, bool(vt),
                               _DIARY[name] if i == len(rows) - 1 else ""))
    return out


SCENARIOS = list(_SC)
