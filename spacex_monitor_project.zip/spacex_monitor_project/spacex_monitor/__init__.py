"""SpaceX Health Tracker - monitoring core (demo, standard library only)."""
__version__ = "0.1.0"
