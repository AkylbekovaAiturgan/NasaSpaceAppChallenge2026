"""Small JSON API (standard library). Run: python main.py serve

GET  /api/status?astronaut=A1   -> assessment + progress
GET  /api/history?astronaut=A1  -> last 7 records
POST /api/records               -> add / replace a daily record (JSON body)
"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from .analyzer import analyse, ACTIONS
from .gamification import progress, challenges, achievements
from .models import DailyRecord


def make_handler(storage):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, payload):
            body = json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_GET(self):
            url = urlparse(self.path)
            aid = parse_qs(url.query).get("astronaut", ["A1"])[0]
            hist = storage.history(aid, days=7)
            if not hist:
                return self._send(404, {"error": "no data for " + aid})
            if url.path == "/api/status":
                a = analyse(hist)
                return self._send(200, {**a.to_dict(), "action": ACTIONS[a.overall],
                                        "progress": progress(storage.history(aid)),
                                        "challenges": challenges(hist[-1]),
                                        "achievements": achievements(hist)})
            if url.path == "/api/history":
                return self._send(200, [r.to_dict() for r in hist])
            self._send(404, {"error": "not found"})

        def do_POST(self):
            if self.path != "/api/records":
                return self._send(404, {"error": "not found"})
            try:
                data = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                rec = DailyRecord(**data)
            except (ValueError, TypeError) as e:
                return self._send(400, {"error": str(e)})
            storage.save(rec)
            self._send(201, {"saved": rec.date})

        def log_message(self, *a):
            pass
    return Handler


def serve(storage, port=8000):
    print(f"API on http://localhost:{port}/api/status?astronaut=A1  (Ctrl+C to stop)")
    ThreadingHTTPServer(("", port), make_handler(storage)).serve_forever()
