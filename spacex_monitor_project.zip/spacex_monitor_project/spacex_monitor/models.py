from dataclasses import dataclass, field, asdict
from enum import IntEnum


class Status(IntEnum):
    GREEN = 0     # normal
    YELLOW = 1    # attention
    RED = 2       # critical


@dataclass
class DailyRecord:
    astronaut_id: str
    date: str                 # ISO date, e.g. "2026-11-15"
    sleep_hours: float
    exercise_min: int
    heart_rate: int           # resting, bpm
    stress: int               # 1-10
    meals: int
    vitamins: bool
    diary: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class Alert:
    level: Status
    code: str
    message: str


@dataclass
class Assessment:
    overall: Status
    indicators: dict = field(default_factory=dict)   # name -> Status
    alerts: list = field(default_factory=list)       # list[Alert]

    def to_dict(self):
        return {
            "overall": self.overall.name,
            "indicators": {k: v.name for k, v in self.indicators.items()},
            "alerts": [{"level": a.level.name, "code": a.code, "message": a.message}
                       for a in self.alerts],
        }
