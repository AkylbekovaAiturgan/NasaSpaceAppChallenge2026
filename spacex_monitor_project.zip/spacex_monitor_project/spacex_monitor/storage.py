"""SQLite storage (file or ':memory:')."""
import sqlite3
from .models import DailyRecord

FIELDS = ["astronaut_id", "date", "sleep_hours", "exercise_min", "heart_rate",
          "stress", "meals", "vitamins", "diary"]


class Storage:
    def __init__(self, path="spacex.db"):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS records(
            astronaut_id TEXT, date TEXT, sleep_hours REAL, exercise_min INTEGER,
            heart_rate INTEGER, stress INTEGER, meals INTEGER, vitamins INTEGER,
            diary TEXT, PRIMARY KEY (astronaut_id, date))""")

    def save(self, r: DailyRecord):
        """Insert or replace the record of that day."""
        vals = [int(getattr(r, f)) if f == "vitamins" else getattr(r, f) for f in FIELDS]
        self.db.execute(f"INSERT OR REPLACE INTO records VALUES ({','.join('?' * len(FIELDS))})", vals)
        self.db.commit()

    def history(self, astronaut_id, days=None) -> list:
        rows = self.db.execute(
            f"SELECT {','.join(FIELDS)} FROM records WHERE astronaut_id=? ORDER BY date",
            (astronaut_id,)).fetchall()
        recs = [DailyRecord(*row[:7], bool(row[7]), row[8]) for row in rows]
        return recs[-days:] if days else recs

    def astronauts(self):
        return [r[0] for r in self.db.execute("SELECT DISTINCT astronaut_id FROM records")]
