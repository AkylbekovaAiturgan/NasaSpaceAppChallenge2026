"""Settings. All limits are EXAMPLES. Real limits must be set by medical experts."""

THRESHOLDS = {
    "sleep_hours":  {"green_min": 7.0, "yellow_min": 6.0},
    "exercise_min": {"green_min": 120, "yellow_min": 60},
    "heart_rate":   {"green": (50, 90), "yellow": (40, 110)},   # resting bpm
    "stress":       {"green_max": 4, "yellow_max": 7},          # scale 1-10
    "meals":        {"green_min": 3},
}

# Trend rules
SLEEP_GOAL = 7.0
SLEEP_BAD_STREAK = 3          # days in a row under the goal -> yellow
SLEEP_DROP = 0.7              # hours: last 3 days vs. previous 3 days
MANY_BAD_INDICATORS = 3       # this many non-green indicators -> yellow

# Diary keywords (English + Russian)
DIARY_RED = ["chest", "faint", "blurry", "vision", "breath", "боль в груди", "зрени", "обморок"]
DIARY_YELLOW = ["tired", "dizzy", "headache", "anxious", "nausea", "lonely", "sad",
                "insomnia", "уста", "головокруж", "голов", "тревог"]

# Gamification
XP_PER_GREEN = 10
XP_DIARY = 25
XP_ALL_GREEN = 50
XP_PER_LEVEL = 100
