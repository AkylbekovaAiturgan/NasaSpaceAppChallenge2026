from . import config as C
from .analyzer import rate_indicators
from .models import Status


def xp_for(rec) -> int:
    greens = sum(1 for s in rate_indicators(rec).values() if s == Status.GREEN)
    xp = greens * C.XP_PER_GREEN
    if rec.diary.strip():
        xp += C.XP_DIARY
    if greens == 5:
        xp += C.XP_ALL_GREEN
    return xp


def progress(history: list) -> dict:
    total = sum(xp_for(r) for r in history)
    return {"xp": total, "level": total // C.XP_PER_LEVEL + 1,
            "to_next": C.XP_PER_LEVEL - total % C.XP_PER_LEVEL}


def challenges(today) -> dict:
    return {"Sleep 7 hours or more": today.sleep_hours >= 7,
            "Exercise 120 minutes": today.exercise_min >= 120,
            "Write a diary entry": bool(today.diary.strip())}


def achievements(history: list) -> dict:
    last3 = history[-3:]
    return {
        "FIRST LOG": len(history) > 0,
        "SLEEP MASTER": len(last3) == 3 and all(r.sleep_hours >= 7 for r in last3),
        "IRON BONES": len(last3) == 3 and all(r.exercise_min >= 120 for r in last3),
        "DIARY KEEPER": any(r.diary.strip() for r in history),
        "ALL GREEN": all(s == Status.GREEN for s in rate_indicators(history[-1]).values()),
    }
