import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from spacex_monitor.analyzer import analyse, rate_heart, rate_sleep
from spacex_monitor.gamification import progress
from spacex_monitor.models import Status
from spacex_monitor.simulator import scenario
from spacex_monitor.storage import Storage


class AnalyzerTests(unittest.TestCase):
    def test_ratings(self):
        self.assertEqual(rate_sleep(7.5), Status.GREEN)
        self.assertEqual(rate_sleep(6.5), Status.YELLOW)
        self.assertEqual(rate_sleep(5.0), Status.RED)
        self.assertEqual(rate_heart(120), Status.RED)

    def test_normal_week_is_green(self):
        self.assertEqual(analyse(scenario("normal")).overall, Status.GREEN)

    def test_bad_sleep_week_has_trend_alerts(self):
        a = analyse(scenario("bad_sleep"))
        codes = {x.code for x in a.alerts}
        self.assertGreaterEqual(a.overall, Status.YELLOW)
        self.assertIn("SLEEP_STREAK", codes)
        self.assertIn("SLEEP_TREND", codes)

    def test_critical_week_is_red(self):
        self.assertEqual(analyse(scenario("critical")).overall, Status.RED)

    def test_trend_warning_when_today_is_still_normal(self):
        hist = scenario("normal")
        for r, sl in zip(hist[:3], (8.5, 8.4, 8.5)):
            r.sleep_hours = sl
        for r, sl in zip(hist[3:6], (7.5, 7.4, 7.2)):
            r.sleep_hours = sl
        a = analyse(hist)
        self.assertIn("SLEEP_TREND", {x.code for x in a.alerts})

    def test_storage_and_xp(self):
        store = Storage(":memory:")
        for r in scenario("normal"):
            store.save(r)
        hist = store.history("A1")
        self.assertEqual(len(hist), 7)
        self.assertGreater(progress(hist)["xp"], 0)


if __name__ == "__main__":
    unittest.main()
